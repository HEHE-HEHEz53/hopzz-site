#!/bin/bash
# =====================================================================
# 部署「鲸鱼娘在线」网页端
# 用法：
#   bash install_chat.sh ai.example.com        # 域名（自动签 HTTPS 证书）
#   bash install_chat.sh 1.2.3.4:8888          # IP:端口（纯 HTTP，不签证书）
# 幂等；已有令牌/证书会保留。
# =====================================================================
set -euo pipefail

ADDR="${1:-${ADDR:-ai.hopzz.top}}"
SRC="$(cd "$(dirname "$0")" && pwd)"
APP="/opt/hopzz-chat"
ACME="/var/www/certbot"

step() { echo; echo "========== $* =========="; }

[[ $EUID -eq 0 ]] || { echo "需要 root"; exit 1; }
command -v nginx >/dev/null || { echo "没装 nginx：apt -y install nginx"; exit 1; }
command -v python3 >/dev/null || { echo "没装 python3"; exit 1; }
if ! command -v rsync >/dev/null 2>&1; then
  echo "没装 rsync，尝试自动安装…"
  apt-get -y install rsync >/dev/null 2>&1 || echo "rsync 装不上，将改用 cp -a"
fi

if [[ "$ADDR" == *:* ]]; then
  # IP:端口 或 域名:端口 → 纯 HTTP
  MODE="ipport"
  LISTEN_PORT="${ADDR##*:}"
  HOST_ONLY="${ADDR%%:*}"
elif [[ "$ADDR" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]]; then
  # 只填了 IP（没端口）→ 默认 8888 端口，纯 HTTP，不申请证书
  MODE="ipport"
  LISTEN_PORT="8888"
  HOST_ONLY="$ADDR"
else
  MODE="domain"
  LISTEN_PORT="443"
  HOST_ONLY="$ADDR"
fi

step "0. 目标：$ADDR（模式：$MODE）"

step "1. 目录与文件"
mkdir -p "$APP/server" "$APP/static" "$APP/data" "$ACME"
if command -v rsync >/dev/null 2>&1; then rsync -a "$SRC/server/" "$APP/server/"; else cp -a "$SRC/server/." "$APP/server/"; fi
if [ -d "$SRC/static" ]; then if command -v rsync >/dev/null 2>&1; then rsync -a "$SRC/static/" "$APP/static/"; else cp -a "$SRC/static/." "$APP/static/"; fi; fi
echo "已同步到 $APP"

step "2. 密钥（只生成一次）"
if [[ ! -f "$APP/.env" ]]; then
  cat > "$APP/.env" <<EOF
AGENT_TOKEN=$(openssl rand -hex 32)
COOKIE_SECRET=$(openssl rand -hex 32)
DB_PATH=$APP/data/chat.db
STATIC_DIR=$APP/static
EOF
  chmod 600 "$APP/.env"
  echo "已生成 AGENT_TOKEN / COOKIE_SECRET"
else
  echo "配置已存在，保留"
fi

step "3. Python 依赖"
# ensurepip（python3-venv 包）在 Debian 上是可选的，必须先补上
if ! python3 -c 'import ensurepip' >/dev/null 2>&1; then
  echo "缺少 python3-venv，尝试自动安装…"
  apt-get update -qq >/dev/null 2>&1 || true
  apt-get -y install python3-venv python3-pip >/dev/null 2>&1 || true
fi

# venv 存在但不可用（没有 pip / ensurepip）也要重建
if [[ -x "$APP/venv/bin/python" ]] && ! "$APP/venv/bin/python" -m pip --version >/dev/null 2>&1; then
  echo "现有的 venv 不可用（缺 pip），重建中…"
  rm -rf "$APP/venv"
fi

if [[ ! -x "$APP/venv/bin/python" ]]; then
  if ! python3 -m venv "$APP/venv" >/dev/null 2>&1; then
    echo "venv 创建失败，改用系统 Python 兼容模式"
    rm -rf "$APP/venv"
    mkdir -p "$APP/venv/bin"
    ln -sf "$(command -v python3)" "$APP/venv/bin/python"
    ln -sf "$(command -v python3)" "$APP/venv/bin/python3"
    PIPFLAGS="--break-system-packages"
  fi
fi

# 补齐 pip（有些环境 venv 建出来不自带 pip）
if ! "$APP/venv/bin/python" -m pip --version >/dev/null 2>&1; then
  "$APP/venv/bin/python" -m ensurepip --upgrade >/dev/null 2>&1 || true
fi
if ! "$APP/venv/bin/python" -m pip --version >/dev/null 2>&1; then
  echo "pip 仍不可用，改用系统 pip（--break-system-packages）"
  apt-get -y install python3-pip >/dev/null 2>&1 || true
  PIPFLAGS="--break-system-packages"
fi

if [[ -x "$APP/venv/bin/pip" ]]; then
  "$APP/venv/bin/pip" install --quiet --upgrade pip
  "$APP/venv/bin/pip" install --quiet fastapi uvicorn "websockets>=12"
else
  "$APP/venv/bin/python" -m pip install --quiet ${PIPFLAGS:-} --upgrade pip >/dev/null 2>&1 || true
  "$APP/venv/bin/python" -m pip install --quiet ${PIPFLAGS:-} fastapi uvicorn "websockets>=12" || {
    apt-get -y install python3-pip >/dev/null 2>&1 || true
    "$APP/venv/bin/python" -m pip install --quiet ${PIPFLAGS:-} fastapi uvicorn "websockets>=12"
  }
fi

step "4. 权限与 systemd"
chown -R www-data:www-data "$APP/data" "$APP/static"
chmod 750 "$APP/data"
install -m 644 "$SRC/systemd/hopzz-chat.service" /etc/systemd/system/hopzz-chat.service
systemctl daemon-reload
systemctl enable hopzz-chat >/dev/null
systemctl restart hopzz-chat
sleep 2
systemctl is-active --quiet hopzz-chat || { echo "启动失败："; journalctl -u hopzz-chat -n 30 --no-pager; exit 1; }
curl -fsS --max-time 5 http://127.0.0.1:8100/api/setup-state && echo

if [[ "$MODE" == "domain" ]]; then
  step "5. 证书（$HOST_ONLY）"
  if [[ ! -d "/etc/letsencrypt/live/$HOST_ONLY" ]]; then
    cat > /etc/nginx/sites-available/_acme-temp.conf <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $HOST_ONLY;
    location /.well-known/acme-challenge/ { root $ACME; }
    location / { return 200 'ok'; add_header Content-Type text/plain; }
}
EOF
    ln -sf /etc/nginx/sites-available/_acme-temp.conf /etc/nginx/sites-enabled/_acme-temp.conf
    nginx -t && systemctl reload nginx
    command -v certbot >/dev/null || apt-get -y install certbot >/dev/null
    certbot certonly --webroot -w "$ACME" -d "$HOST_ONLY" \
      --non-interactive --agree-tos --register-unsafely-without-email --keep-until-expiring || true
    rm -f /etc/nginx/sites-enabled/_acme-temp.conf /etc/nginx/sites-available/_acme-temp.conf
  fi
  if [[ ! -d "/etc/letsencrypt/live/$HOST_ONLY" ]]; then
    echo "!! 证书没拿到（域名可能没解析到这台机器），自动改用 HTTP 模式"
    MODE="ipport"
    LISTEN_PORT="80"
  fi
fi

step "6. 安装 nginx 站点"
CONF="/etc/nginx/sites-available/hopzz-chat-$HOST_ONLY.conf"
if [[ "$MODE" == "domain" ]]; then
  sed "s/ai\.hopzz\.top/$HOST_ONLY/g" "$SRC/nginx/ai.hopzz.top.conf" > "$CONF"
else
  cat > "$CONF" <<EOF
server {
    listen $LISTEN_PORT;
    listen [::]:$LISTEN_PORT;
    server_name _;
    client_max_body_size 0;
    add_header X-Content-Type-Options nosniff always;

    location /ws {
        proxy_pass http://127.0.0.1:8100;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
    }
    location /agent-ws {
        proxy_pass http://127.0.0.1:8100;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$host;
        proxy_read_timeout 3600s;
        proxy_send_timeout 3600s;
        access_log off;
    }
    location / {
        proxy_pass http://127.0.0.1:8100;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_read_timeout 360s;
    }
}
EOF
fi
ln -sf "$CONF" "/etc/nginx/sites-enabled/$(basename "$CONF")"
nginx -t
systemctl reload nginx

step "7. 验证"
if [[ "$MODE" == "domain" ]]; then URL="https://$HOST_ONLY"; else URL="http://$HOST_ONLY:$LISTEN_PORT"; fi
echo "访问地址：$URL"
c1=$(curl -s -o /dev/null -w '%{http_code}' "$URL/" || echo ERR)
c2=$(curl -s -o /dev/null -w '%{http_code}' "$URL/api/setup-state" || echo ERR)
echo "首页 $c1   接口 $c2"

TOKEN="$(grep '^AGENT_TOKEN=' "$APP/.env" | cut -d= -f2-)"
echo
echo "========== 完成 =========="
echo "网页地址:   $URL"
if [[ "$MODE" == "domain" ]]; then echo "插件地址:   wss://$HOST_ONLY/agent-ws"; else echo "插件地址:   ws://$HOST_ONLY:$LISTEN_PORT/agent-ws"; fi
echo "插件令牌:   $TOKEN"
echo "首次打开网页会让你设置密码。"
